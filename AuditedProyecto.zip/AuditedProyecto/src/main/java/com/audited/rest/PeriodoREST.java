package com.audited.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.audited.modelo.Periodo;
import com.audited.services.PeriodoServices;

@RestController
@RequestMapping("/periodo/")
public class PeriodoREST {
	@Autowired 
	private PeriodoServices periodo;
	@GetMapping
	private ResponseEntity<List<Periodo>> getAllPeriodo (){
		return ResponseEntity.ok(periodo.findAll());
	}

}
