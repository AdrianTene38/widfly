package com.audited.rest;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.audited.modelo.PlanNacional;
import com.audited.services.PlanNacionalServices;
import java.net.URI;
@RestController
@RequestMapping("/plannacional/")
public class PlanNacionalREST {
@Autowired 
private PlanNacionalServices plnacional;
@GetMapping
private ResponseEntity<List<PlanNacional>> getAllPersonas (){
	java.util.Date fecha = new Date();;
	System.out.println (fecha.getDay());
	System.out.println (fecha.getMonth());
	return ResponseEntity.ok(plnacional.findAll());
}
@DeleteMapping (value = "delete/{id}")
private ResponseEntity<Boolean> deletePersona (@PathVariable ("id") Long id){
	plnacional.deleteById(id);
	return ResponseEntity.ok(!(plnacional.findById(id)!=null));
	
}
@PostMapping
private ResponseEntity<PlanNacional> savePlanNacional (@RequestBody PlanNacional plan){
	try {
		plan.setFdesde("12/12/12");
//plan.setPeriodofin()
		plan.setFecha_modificacion("10/10/10");
		plan.setCreacion_usuario("12/12/12");
		plan.setFecha_creacion("10/12/2015");
		PlanNacional planGuardada = plnacional.save(plan);	
		System.out.println("q fueeeeeee");
	return ResponseEntity.created(new URI("/plannuevo/"+planGuardada.getId())).body(planGuardada);
	} catch (Exception e) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			
	}
}



}
