package com.audited.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "T_PERIODO")
public class Periodo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id_periodo;
	private int periodo;
	private String fdesde;
	private String fhasta;
	private String activo;
	private boolean eliminado;

	
	public boolean isEliminado() {
		return eliminado;
	}
	public void setEliminado(boolean eliminado) {
		this.eliminado = eliminado;
	}
	public Long getId_periodo() {
		return id_periodo;
	}
	public void setId_periodo(Long id_periodo) {
		this.id_periodo = id_periodo;
	}
	public int getPeriodo() {
		return periodo;
	}
	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}
	public String getFdesde() {
		return fdesde;
	}
	public void setFdesde(String fdesde) {
		this.fdesde = fdesde;
	}
	public String getFhasta() {
		return fhasta;
	}
	public void setFhasta(String fhasta) {
		this.fhasta = fhasta;
	}
	public String getActivo() {
		return activo;
	}
	public void setActivo(String activo) {
		this.activo = activo;
	}
	public Periodo(int periodo, String fdesde, String fhasta, String activo) {
		super();
		this.periodo = periodo;
		this.fdesde = fdesde;
		this.fhasta = fhasta;
		this.activo = activo;
	}
	public Periodo() {
		super();
	}

	
}
