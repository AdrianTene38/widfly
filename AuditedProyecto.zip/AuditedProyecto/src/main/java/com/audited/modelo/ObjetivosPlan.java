package com.audited.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name = "T_OBJETIVOS_PLAN")
public class ObjetivosPlan {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@ManyToOne
	@JoinColumn (name="id_ejes_plan")
	private EjesPlan ejesplan;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public EjesPlan getEjesplan() {
		return ejesplan;
	}
	public void setEjesplan(EjesPlan ejesplan) {
		this.ejesplan = ejesplan;
	}
	public PlanNacional getPlan() {
		return plan;
	}
	public void setPlan(PlanNacional plan) {
		this.plan = plan;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	@ManyToOne
	@JoinColumn (name="id_plan_nacional")
	private PlanNacional plan;
	private String nombre;
	private String descripcion;
	private String fdesde;
	private String fhasta;
	private String creacion_usuario;
	private String fecha_creacion;
	private String fecha_modificacion;
	private boolean eliminado;
	
	public boolean isEliminado() {
		return eliminado;
	}
	public void setEliminado(boolean eliminado) {
		this.eliminado = eliminado;
	}
	public String getFdesde() {
		return fdesde;
	}
	public void setFdesde(String fdesde) {
		this.fdesde = fdesde;
	}
	public String getFhasta() {
		return fhasta;
	}
	public void setFhasta(String fhasta) {
		this.fhasta = fhasta;
	}
	public String getCreacion_usuario() {
		return creacion_usuario;
	}
	public void setCreacion_usuario(String creacion_usuario) {
		this.creacion_usuario = creacion_usuario;
	}
	public String getFecha_creacion() {
		return fecha_creacion;
	}
	public void setFecha_creacion(String fecha_creacion) {
		this.fecha_creacion = fecha_creacion;
	}
	public String getFecha_modificacion() {
		return fecha_modificacion;
	}
	public void setFecha_modificacion(String fecha_modificacion) {
		this.fecha_modificacion = fecha_modificacion;
	}
	public ObjetivosPlan(EjesPlan ejesplan, PlanNacional plan, String nombre, String descripcion) {
		super();
		this.ejesplan = ejesplan;
		this.plan = plan;
		this.nombre = nombre;
		this.descripcion = descripcion;
	}

	
}
