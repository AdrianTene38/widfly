package com.audited.modelo;

public class Plan {
	private int id;
	private PlanNacional plan;
	private String nombre;
	private String descripcion;
	
}
