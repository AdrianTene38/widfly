package com.audited.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.audited.modelo.PlanNacional;


public interface PlanNacionalRepository extends JpaRepository<PlanNacional, Long> {

}
