package com.audited.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.audited.modelo.ObjetivosPlan;

public interface ObjetivosPlanRepository extends JpaRepository<ObjetivosPlan, Long>{

}
